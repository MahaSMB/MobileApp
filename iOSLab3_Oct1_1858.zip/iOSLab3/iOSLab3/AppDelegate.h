//
//  AppDelegate.h
//  iOSLab3
//
//  Created by Maha Basheikh on 2023-09-29.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

