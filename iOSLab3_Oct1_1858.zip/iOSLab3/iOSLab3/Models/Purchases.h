//
//  Purchases.h
//  iOSLab3
//
//  Created by Maha Basheikh on 2023-09-29.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Purchases : NSObject

@end

NS_ASSUME_NONNULL_END
