//
//  Model.swift
//  ImageViewer
//
//  Created by Maha Basheikh on 2023-10-10.
//

import UIKit

class Model {
    lazy var listOfImages = ["Sunset":"https://images.freeimages.com/images/large-previews/1c9/maine-at-4-45-am-1370871.jpg",
                             "Sunrise": "https://images.freeimages.com/images/large-previews/07c/sunrise-beach-1516936.jpg",
                             "Jupiter": "https://images.freeimages.com/images/large-previews/e06/jupiter-1153866.jpg",
                             "Mars": "https://images.freeimages.com/images/large-previews/9cc/red-planet-rise-1629776.jpg",
                             "Saturn": "https://images.freeimages.com/images/large-previews/a76/saturn-hd-planet-1152093.jpg"]
    
}
