public struct MyMain {
    public private(set) var text = "Hello, World!"

    public init() {
    }
}
