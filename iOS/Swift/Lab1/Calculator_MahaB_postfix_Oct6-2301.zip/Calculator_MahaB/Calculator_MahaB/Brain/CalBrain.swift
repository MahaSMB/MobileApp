//
//  CalBrain.swift
//  Calculator_MahaB
//
//  Created by Maha Basheikh on 2023-10-05.
//

import UIKit

class CalBrain: NSObject {

}
