//
//  Store.m
//  iOSMidterm
//
//  Created by Maha Basheikh on 2023-10-02.
//

#import "Store.h"
#import "Ticket.h"
#import "Transactions.h"

@interface Store()

@end

@implementation Store
-(NSArray *) listOfTicketTypes {
    if(_listOfTicketTypes == nil)
        _listOfTicketTypes = [[NSArray alloc]initWithObjects:
                              [[Ticket alloc]initWithTitle:@"VIP"],
                              [[Ticket alloc]initWithTitle:@"Business"],
                              [[Ticket alloc]initWithTitle:@"Economy Adult"],
                              [[Ticket alloc]initWithTitle:@"Economy Kid"],
                              [[Ticket alloc]initWithTitle:@"Infant"],
                              nil];
    return _listOfTicketTypes;
}

-(NSMutableArray *) purchaseTransactions {
    if(_purchaseTransactions == nil)
        _purchaseTransactions = [[NSMutableArray alloc]init];
    return _purchaseTransactions;
}

-(NSString *) ticketTransaction:(int)chosenQty andRow: (int) row {
    Ticket *ticketType = [self.listOfTicketTypes objectAtIndex:row];
        
    return [NSString stringWithFormat:@"%@ quantity %d", ticketType.title, chosenQty];
}

-(id)TransactionItemAtRow:(int)row {
    Transactions *purchaseTrans = [self.purchaseTransactions objectAtIndex:row];
    return purchaseTrans;
}
@end
