//
//  TransactionsViewController.h
//  iOSMidterm
//
//  Created by Maha Basheikh on 2023-10-02.
//

#import <UIKit/UIKit.h>

#import "ViewController.h"
#import "Ticket.h"
#import "Store.h"
#import "Transactions.h"
#import "TransactionsViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface TransactionsViewController : UIViewController
@property (nonatomic) NSMutableArray *purchaseTransactions;
-(NSMutableArray *)purchaseTransactions;
@end

NS_ASSUME_NONNULL_END
