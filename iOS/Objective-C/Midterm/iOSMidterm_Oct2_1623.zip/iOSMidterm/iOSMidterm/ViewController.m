//
//  ViewController.m
//  iOSMidterm
//
//  Created by Maha Basheikh on 2023-10-02.
//

#import "ViewController.h"
#import "Ticket.h"
#import "Store.h"
#import "Transactions.h"
#import "TransactionsViewController.h"

@interface ViewController () <UIPickerViewDelegate, UIPickerViewDataSource, UITextViewDelegate, UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIPickerView *pickerView;
@property (weak, nonatomic) IBOutlet UILabel *instructionsLabel;
@property (weak, nonatomic) IBOutlet UITextField *numberEntryField;
@property (weak, nonatomic) IBOutlet UITextView *myTextView;
//@property(nonatomic) UIReturnKeyType returnKeyType;

@property (nonatomic) int chosenRow;
@property (nonatomic) Store *storeItem;
@property (nonatomic) NSString *nextLine;
//-(BOOL)textFieldShouldReturn:(UITextField *)textField;
@end

@implementation ViewController
-(Store *)storeItem {
    if(_storeItem == nil) {
        _storeItem = [[Store alloc]init];
    }
    return _storeItem;
}

-(void)viewDidLoad {
    [super viewDidLoad];
    //[self.pickerView reloadAllComponents];
    self.instructionsLabel.text = @"Choose your ticket type and number";
    //self.numberEntryLabel.text = @"";
    // Do any additional setup after loading the view.
}

-(void)viewDidAppear:(BOOL)animated {
    //self.chosenRow = -1;
    [self.pickerView reloadAllComponents];
}


-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return self.storeItem.listOfTicketTypes.count;
}

-(NSString *)pickerView:(UIPickerView *)pickerView
            titleForRow:(NSInteger)row
           forComponent:(NSInteger)component {
    
    Ticket *ticketItem = [self.storeItem.listOfTicketTypes objectAtIndex:row];
    
    return [NSString stringWithFormat:@"%@", ticketItem.title];
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    self.chosenRow = (int) row;
}

//- (IBAction)numberEntryEnterPressed:(UITextField *)sender {
//    if (self.numberEntryField.text.length > 0){
//        int quantity = [self.numberEntryField.text intValue];
//        self.nextLine = [self.storeItem ticketTransaction:quantity andRow:self.chosenRow];
//    }
//}
- (IBAction)numberEntry:(UITextField *)sender {
    if (self.numberEntryField.text.length > 0){
        int quantity = [self.numberEntryField.text intValue];
        
        Ticket *ticketItem = [self.storeItem.listOfTicketTypes objectAtIndex:self.chosenRow];
        
        //self.nextLine = [NSString stringWithFormat:@"%@ quantity %d", ticketItem.title, quantity];
        
        //Transactions *purchaseTrans = [self.storeItem TransactionItemAtRow:self.chosenRow];
        
        // Add Object to the list of transactions NSMutableArray
        Transactions *purchaseTrans = [[Transactions alloc]initWithTitle:ticketItem.title andQty: quantity];
        
        [self.storeItem.purchaseTransactions addObject:purchaseTrans];
        //NSLog(self.nextLine);
        
        self.myTextView.text = [NSString stringWithFormat:@"%@ quantity %d", ticketItem.title, quantity];
        
        
        //self.myTextView.text = self.nextLine;
    }
}

-(void)textViewDidEndEditing:(UITextView *)textView {
    // Dismiss the keyboard after user presses enter
    [self.numberEntryField resignFirstResponder];
    
   
    
    
}

//- (BOOL)textFieldShouldReturn:(UITextField *)textField{
//
//}




- (IBAction)addMoreButton:(UIButton *)sender {
    
//    if (self.myTextView.text.length > 0){
//        self.myTextView.text = [NSString stringWithFormat:@"%@ quantity %d", ticketItem.title, quantity];
//    }
}

- (IBAction)checkoutButton:(UIButton *)sender {
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if([segue.identifier isEqualToString:@"TransSegue"]) {
        TransactionsViewController *tvc = segue.destinationViewController;
        //tvc.managerMenuTitleText = @"Transactions Panel Menu";
        tvc.purchaseTransactions = self.storeItem.purchaseTransactions;
        //tvc.ticketStock = self.storeItem.listOfTickets;
    }
}

@end
