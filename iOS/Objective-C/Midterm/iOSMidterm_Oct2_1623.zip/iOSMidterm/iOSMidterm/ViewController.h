//
//  ViewController.h
//  iOSMidterm
//
//  Created by Maha Basheikh on 2023-10-02.
//

#import <UIKit/UIKit.h>
#import "Ticket.h"
#import "Store.h"
#import "Transactions.h"
#import "TransactionsViewController.h"


@interface ViewController : UIViewController


@end

