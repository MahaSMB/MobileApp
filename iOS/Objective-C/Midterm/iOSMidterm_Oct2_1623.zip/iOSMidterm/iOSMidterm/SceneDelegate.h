//
//  SceneDelegate.h
//  iOSMidterm
//
//  Created by Maha Basheikh on 2023-10-02.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

