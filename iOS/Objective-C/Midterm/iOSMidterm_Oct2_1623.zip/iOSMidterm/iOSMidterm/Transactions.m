//
//  Transactions.m
//  iOSMidterm
//
//  Created by Maha Basheikh on 2023-10-02.
//

#import "Transactions.h"
#import "ViewController.h"
#import "Ticket.h"
#import "Store.h"
#import "TransactionsViewController.h"

@implementation Transactions
- (instancetype)initWithTitle:(NSString *) title andQty:(int) qty {
    self = [super init];
        if (self) {
            self.title = title;
            self.qty = qty;
    }
    return self;
}

@end
