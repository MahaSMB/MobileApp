//
//  TransactionsViewController.m
//  iOSMidterm
//
//  Created by Maha Basheikh on 2023-10-02.
//

#import "TransactionsViewController.h"


#import "ViewController.h"
#import "Ticket.h"
#import "Store.h"
#import "Transactions.h"
#import "TransactionsViewController.h"

@interface TransactionsViewController () <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic) Store *transactionsStoreItem;
@property (nonatomic) Transactions *transactionsItem;
@property (nonatomic) int selectedRow;
@end

@implementation TransactionsViewController

-(Store *)transactionsStoreItem {
    if(_transactionsStoreItem == nil) {
        _transactionsStoreItem = [[Store alloc]init];
    }
    return _transactionsStoreItem;
}

-(NSMutableArray *) purchaseTransactions {
    if(_purchaseTransactions == nil)
        _purchaseTransactions = [[NSMutableArray alloc]init];
    return _purchaseTransactions;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // return the number of of rows dependent on number of transactions in the purchase history
    return self.transactionsStoreItem.purchaseTransactions.count;
    //return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *myCell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    Transactions *purchaseTrans = [self.transactionsStoreItem.purchaseTransactions objectAtIndex:indexPath.row];
    myCell.textLabel.text = purchaseTrans.title;
    myCell.detailTextLabel.text = [NSString stringWithFormat:@"%d", purchaseTrans.qty];
        
    //NSLog(@"Purchase History Page: Purchases made for %@ tickets for a quantity of %@ .", myCell.textLabel.text, myCell.detailTextLabel.text);
        
    return myCell;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
