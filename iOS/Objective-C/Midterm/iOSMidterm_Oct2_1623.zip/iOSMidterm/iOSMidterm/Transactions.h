//
//  Transactions.h
//  iOSMidterm
//
//  Created by Maha Basheikh on 2023-10-02.
//

#import <Foundation/Foundation.h>
#import "ViewController.h"
#import "Ticket.h"
#import "Store.h"
#import "TransactionsViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface Transactions : NSObject
@property (nonatomic) NSMutableArray *purchaseTransactions;
@property (nonatomic) NSString *title;
@property (nonatomic) int qty;
-(instancetype)initWithTitle:(NSString *) title andQty:(int) qty;
@end

NS_ASSUME_NONNULL_END
