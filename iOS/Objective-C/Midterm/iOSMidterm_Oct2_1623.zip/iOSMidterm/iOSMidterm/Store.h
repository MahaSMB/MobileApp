//
//  Store.h
//  iOSMidterm
//
//  Created by Maha Basheikh on 2023-10-02.
//

#import <Foundation/Foundation.h>
#import "Ticket.h"

NS_ASSUME_NONNULL_BEGIN

@interface Store : NSObject
@property (nonatomic) NSArray *listOfTicketTypes;
-(NSArray *) listOfTicketTypes;

@property (nonatomic) NSString  *ticketTransaction;
-(NSString *) ticketTransaction:(int)chosenQty andRow: (int) row;

@property (nonatomic) NSMutableArray *purchaseTransactions;
-(NSMutableArray *)purchaseTransactions;

-(id)TransactionItemAtRow:(int)row;
@end

NS_ASSUME_NONNULL_END
