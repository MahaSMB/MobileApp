//
//  Ticket.h
//  iOSMidterm
//
//  Created by Maha Basheikh on 2023-10-02.
//

#import <Foundation/Foundation.h>

#import "ViewController.h"
#import "Store.h"
#import "Transactions.h"
#import "TransactionsViewController.h"


NS_ASSUME_NONNULL_BEGIN

@interface Ticket : NSObject
@property (nonatomic) NSString *title;
-(instancetype)initWithTitle:(NSString *) title;
@end

NS_ASSUME_NONNULL_END
