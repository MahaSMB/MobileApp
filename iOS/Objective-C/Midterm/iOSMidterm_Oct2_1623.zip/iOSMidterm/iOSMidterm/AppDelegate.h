//
//  AppDelegate.h
//  iOSMidterm
//
//  Created by Maha Basheikh on 2023-10-02.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

