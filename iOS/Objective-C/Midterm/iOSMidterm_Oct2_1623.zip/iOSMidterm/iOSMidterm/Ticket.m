//
//  Ticket.m
//  iOSMidterm
//
//  Created by Maha Basheikh on 2023-10-02.
//

#import "Ticket.h"

#import "ViewController.h"
#import "Store.h"
#import "Transactions.h"
#import "TransactionsViewController.h"

@implementation Ticket
-(instancetype)initWithTitle:(NSString *) title {
    self = [super init];
    if (self) {
        self.title = title;
    }
    return self;
}
@end
