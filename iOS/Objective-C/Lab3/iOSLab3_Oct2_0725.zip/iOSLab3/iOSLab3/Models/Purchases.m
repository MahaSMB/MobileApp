//
//  Purchases.m
//  iOSLab3
//
//  Created by Maha Basheikh on 2023-09-29.
//

#import "Purchases.h"

@implementation Purchases

@end
