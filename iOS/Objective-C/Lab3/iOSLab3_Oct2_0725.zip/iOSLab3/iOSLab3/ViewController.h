//
//  ViewController.h
//  iOSLab3
//
//  Created by Maha Basheikh on 2023-09-29.
//

#import <UIKit/UIKit.h>
#import "Ticket.h"
#import "Store.h"
#import "Purchases.h"
//#import "Store.h"


@interface ViewController : UIViewController
//-(void)updateListOfTickets: (NSMutableArray *) newInventory;

@end

