//
//  Model.swift
//  ImageViewer
//
//  Created by Maha Basheikh on 2023-10-10.
//

import UIKit

class Model {
    lazy var listOfImages = ["Sunset":"https://images.freeimages.com/images/large-previews/1c9/maine-at-4-45-am-1370871.jpg",
                             "Sunrise": "https://www.freeimages.com/photo/sunrise-beach-1516936",
                             "Jupiter": "https://www.freeimages.com/photo/jupiter-1153866",
                             "Mars": "https://www.freeimages.com/photo/mars-2426728",
                             "Saturn": "https://www.freeimages.com/photo/saturn-in-the-galaxy-2284016"]    
    
}
