//
//  ViewController.swift
//  PersonalityQuiz_MahaB
//
//  Created by Maha Basheikh on 2023-10-07.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

