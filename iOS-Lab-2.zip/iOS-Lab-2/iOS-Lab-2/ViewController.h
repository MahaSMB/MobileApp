//
//  ViewController.h
//  iOS-Lab-2
//
//  Created by Maha Basheikh on 9/22/23.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

