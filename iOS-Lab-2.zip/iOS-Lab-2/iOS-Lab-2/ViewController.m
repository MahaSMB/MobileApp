//
//  ViewController.m
//  iOS-Lab-2
//
//  Created by user248611 on 9/22/23.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
