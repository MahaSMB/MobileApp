//
//  SceneDelegate.h
//  iOS-Lab3
//
//  Created by user248611 on 9/28/23.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

