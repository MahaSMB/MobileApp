//
//  Store.h
//  iOS-Lab3
//
//  Created by Maha Basheikh on 9/28/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Store : NSObject
@property (nonatomic) NSMutableArray *listOfTickets;
@end

NS_ASSUME_NONNULL_END
