//
//  ViewController.h
//  iOS-Lab3
//
//  Created by Maha Basheikh on 9/28/23.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController



@end

